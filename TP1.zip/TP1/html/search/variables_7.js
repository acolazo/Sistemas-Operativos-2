var searchData=
[
  ['rafaga_5fmax',['rafaga_max',['../structdatos.html#aee38928b36bde1b1ddede66cf1bea915',1,'datos']]],
  ['rocio',['rocio',['../structdatos.html#ac93660891013484981943e2fe32ecfc2',1,'datos']]]
];
