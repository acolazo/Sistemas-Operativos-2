var searchData=
[
  ['precipitacion',['precipitacion',['../structdatos.html#a895ca1f2cbf77067b75fcbb84fb1171c',1,'datos']]],
  ['presion',['presion',['../structdatos.html#a3a2cc12174c5270d5f097f6e3456f429',1,'datos']]],
  ['punteros',['punteros',['../structdatos.html#a25e0937de3764a91d0aca3a93f5bd9ab',1,'datos']]]
];
