int srv_i_cc( int argc, char *argv[] );
/**
 * @brief Funcion que levanta el server con que se conecta el usuario.
 *
 * @param argc cantidad de strings a pasar.
 * @param argv nombre del programa y puerto a utilizar para la conexion tcp.
 * 
 */
