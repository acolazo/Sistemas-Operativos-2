

#ifndef SRV_I_CC_H
#define SRV_I_CC_H
#include "sock_srv_i_cc.h"
#endif /* HELLO_WORLD_H */
//Deberia hacer un header.



int main( int argc, char *argv[] ) {

	srv_i_cc(argc, argv);

}

