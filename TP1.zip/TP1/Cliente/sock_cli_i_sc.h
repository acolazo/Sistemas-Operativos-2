void receive_file(struct hostent * server_ip, int puerto_udp);
/**
 * @brief Recibe el archivo .csv que el servidor envia.
 *
 * @param server_ip estructura con datos del servidor
 * @param puerto_udp int con el numero de puerto del servidor UDP.
 * 
 */
