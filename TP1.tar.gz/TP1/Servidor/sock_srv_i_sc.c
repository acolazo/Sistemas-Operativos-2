#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#ifndef OPENFILE_H
#define OPENFILE_H
#include "openfile.h"
#endif 
#include "sock_srv_i_sc.h"
#define TAM 1024


void sendfile_sc( int port_number , int *fd) {
	int sockfd, puerto;
	socklen_t tamano_direccion;
	char buffer[ TAM ];
	char buffer_send [TAM];
	struct sockaddr_in serv_addr;
	int n;
	FILE * file_send;
	int contador = 0;


	file_send=fopen(FILE_TO_SEND, "r");

	

	if(file_send==NULL)
	{
		printf("ERROR AL ABRIR EL ARCHIVO.\n");
		exit(0);
	}




	
	sockfd = socket( AF_INET, SOCK_DGRAM, 0 );
	if (sockfd < 0) { 
		perror("ERROR en apertura de socket");
		exit( 1 );
	}

	memset( &serv_addr, 0, sizeof(serv_addr) );
	puerto = port_number;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons( puerto );
	memset( &(serv_addr.sin_zero), '\0', 8 );

	if( bind( sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr) ) < 0 ) {
		perror( "ERROR en binding" );
		exit( 1 );
	}

	printf( "Socket disponible: %d\n", ntohs(serv_addr.sin_port) );

	tamano_direccion = sizeof( struct sockaddr );

	char message_pipe[10];
	close(fd[0]);
	strcpy(message_pipe, "Continue");
	write(fd[1], message_pipe, 10);
	close(fd[1]);

	while(fgets(buffer_send, TAM, file_send))	
	{	

		memset( buffer, 0, TAM );
		n = recvfrom( sockfd, buffer, TAM-1, 0, (struct sockaddr *)&serv_addr, &tamano_direccion );
		if ( n < 0 ) {
			perror( "lectura de socket" );
			exit( 1 );
		}
		//printf( "Recibí: %s\n", buffer );
		n = sendto( sockfd, (void *)buffer_send, TAM, 0, (struct sockaddr *)&serv_addr, tamano_direccion  );
		if ( n < 0 ) {
			perror( "escritura en socket" );
			exit( 1 );
		}

		//printf("Mandando el numero %d\n", contador);
		contador++;
	}
	n = sendto( sockfd, (void *)"END_CODE", 9, 0, (struct sockaddr *)&serv_addr, tamano_direccion  );
	if ( n < 0 ) {
		perror( "escritura en socket" );
		exit( 1 );
	}	

	printf("FILE SENT\n");
	fclose(file_send);
	close(sockfd);
	return; 
} 
