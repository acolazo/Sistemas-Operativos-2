int cli_i_cc(int argc, char*argv[]);
/**
 * @brief Levanta la aplicacion cliente que se conecta al servidor por TCP y manda los comandos.
 *
 * @param argc cantidad de argumentos que se pasan
 * @param argv arreglo de strings con el nombre del programa, la direccion ip del servidor y el puerto TCP del servidor
 * 
 */
