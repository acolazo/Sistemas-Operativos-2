var searchData=
[
  ['idlocalidad',['idlocalidad',['../structdatos.html#a927e448958bc1d5945ee80dc5f0bf220',1,'datos']]]
];
