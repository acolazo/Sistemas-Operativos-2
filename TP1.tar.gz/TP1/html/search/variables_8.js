var searchData=
[
  ['temperatura',['temperatura',['../structdatos.html#ac60aa86adb8352bd11c92b136c252ef9',1,'datos']]]
];
