var searchData=
[
  ['estacion',['estacion',['../structdatos.html#a29ea9f9a82a90d3da6775773661e5134',1,'datos']]]
];
